/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file Header file for the Statistics File  <Add File Name> 
 * @brief Function declarations file <Add Brief Description Here >
 *
 * <Add Extended Description Here>
 *	Function delcations and explanation on how to use them located in the stats.c file such as find_median(char* arr, int length) and find_maximum(char* arr, int length)...
 *	   
 * @author Hussein HAMADI
 * @date 19/11/2020
 *
 */
#ifndef __STATS_H__
#define __STATS_H__

/* Add Your Declarations and Function Comments here */ 
#ifdef VERBOSE	
	void print_array(unsigned char* arr, unsigned int length);
#endif
/**
* @brief This function prints an array with a size of length on the screen with an array format
*
* This function takes as input an unsigned char pointer to an array as well as an unsigned int length. This function does not return
* anything as it only prints out the array. It will print it out in a nice format with brackets and commas.
*
* @param unsigned char* arr   The array to be printed
* @param unsigned int length  The length of the array
* 
* 
*
* @return Void return type. This function returns nothing.
**/

	void print_statistics(unsigned char* arr, unsigned int length);
       
/**
*   @brief This function prints all the data analysis done on the data array.
*  
*   This function takes as input an unsigned char pointer to an array and the size of the array with an unsigned int length parameter. It will print out all the data analysis
*   done on the array such as the median, the mean value, the maximum and minimum values as well as the array sorted from the largest element to the smallest element.
*   This function does not return anything as it is of type void.
*   
*  
*   @param unsigned char* arr   The array to do the data analysis on.
*   @param unsigned int length  The length of the array.
*   
*   
*  
*   @return Void return type. This function returns nothing.
**/

	void sort_array(unsigned char* arr, unsigned int length);

/**
*    @brief This function sort the array from the largest element to the smallest element in the array.
*   
*    This function takes as input an unsigned char pointer to an array and the size of the array with an unsigned int length parameter. It will sort the array from
*    the largest element to the smallest element which means that the element of index 0 will be the largest element in the array and the element of index length-1
*    will be the smallest element in the array. This function returns nothing as it is of type void.
*    
*   
*    @param unsigned char* arr   The array to be sorted
*    @param unsigned int length  The length of the array.
*    
*    
*   
*    @return Void return type. This function returns nothing.
**/


	unsigned char find_median(unsigned char* arr, unsigned int length);

/**
*    @brief This function finds the median value of the array given of size length.
*    
*    This function takes as input an unsigned char pointer to an array and the size of the array with a unsigned int length parameter. It will find the median
*    value of the array given. This function returns an unsigned char element which represents the median of the array.
*    
*   
*    @param unsigned char* arr   The array in which we want to find the median value.
*    @param unsigned int length  The length of the array.
*    
*    
*   
*    @return unsigned char return type. It will return an unsigned char element which represents the median value of the array.
**/

	unsigned char find_mean(unsigned char* arr, unsigned int length);

/**
*     @brief This function finds the mean value of the array given of size length.
*
*     This function takes as input an unsigned char pointer to an array and the size of the array with an unsigned int length parameter. It will find the mean
*      value of the array given. This function returns an unsigned char element which represents the mean of the array.
*          
*         
*      @param unsigned char* arr   The array in which we want to find the mean value.
*      @param unsigned int length  The length of the array.
*          
*         
*       
*      @return unsigned char return type. It will return an unsigned char element which represents the mean value of the array.
**/

        unsigned char find_maximum(unsigned char* arr, unsigned int length);

/**
*    @brief This function finds the maximum value of the array given of size length.
*       
*    This function takes as input an unsigned char pointer to an array and the size of the array with an unsigned int length parameter. It will find the maximum
*    value of the array given. This function returns an unsigned char element which represents the maximum of the array.
*       
*      
*    @param unsigned char* arr   The array in which we want to find the maximum value.
*    @param unsigned int length  The length of the array.
*       
*       
*      
*    @return unsigned char return type. It will return a unsigned char element which represents the maximum value of the array.
**/

	unsigned char find_minimum(unsigned char* arr, unsigned int length);

/**
*      @brief This function finds the minimum value of the array given of size length.
*      
*      This function takes as input an unsigned char pointer to an array and the size of the array with an unsigned int length parameter. It will find the minimum
*      value of the array given. This function returns an unsigned char element which represents the minimum of the array.
*        
*       
*      @param unsigned char* arr   The array in which we want to find the minimum value.
*      @param unsigned int length  The length of the array.
*        
*         
*        
*      @return unsigned char return type. It will return a unsigned char element which represents the minimum value of the array.
**/


	
#endif /* __STATS_H__ */
