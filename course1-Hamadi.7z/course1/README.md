/* Add Author and Project Details here */

###******************************************************************************
# Copyright (C) 2017 by Alex Fosdick - University of Colorado
#
# Redistribution, modification or use of this software in source or binary
# forms is permitted as long as the files maintain this copyright. Users are 
# permitted to modify this and use it to learn about the field of embedded
# software. Alex Fosdick and the University of Colorado are not liable for any
# misuse of this material. 
#
###*****************************************************************************

# Author: Christian Haddad
# Project Details: This assignment talks about how to use version control in a project as well as C programming
# This repository is for the first assignment for the Introduction to the Embedded Systems course on Coursera
# This repository contains stats.c, the source file containing all the main code implementations.
# It also contains stats.h, the header file of the main source file containing function declarations.
