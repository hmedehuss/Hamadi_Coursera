#include <stdint.h>

uint8_t my_itoa(int32_t data, uint8_t* ptr, uint32_t base){
	int digit6=0;
	int32_t nb=data;
	while(nb>100000){
		digit6=digit6+1; 
		nb=nb-100000;
	}
	int digit5=0;
	while(nb>10000){
		digit5=digit5+1;
		nb=nb-10000;
	}
	int digit4=0;
	while(nb>1000){
		digit4=digit4+1;
		nb=nb-1000;
	}
	int digit3=0;
	while(nb>100){
		digit3=digit3+1;
		nb=nb-100;
	}
	int digit2=0;
	while(nb>10){
		digit2=digit2+1;
		nb=nb-10;
	}
	int digit1=nb;

}





























