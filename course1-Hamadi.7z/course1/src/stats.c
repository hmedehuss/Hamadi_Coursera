/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file Statistics <Add File Name> 
 * @brief Data analysis file on an array <Add Brief Description Here >
 *
 * <Add Extended Description Here>
 *	Data analysis file on a unsigned char array with C functions. Analysis of data will be like calculating the median, maximum, minimum, and mean data of the array 
 *
 * @author Hussein HAMADI
 * @date 19/11/2020
 *
 */



#include "platform.h"
#include "stats.h"

/* Size of the Data Set */
#define SIZE (40)

void main() {

  unsigned char test[SIZE] = { 34, 201, 190, 154,   8, 194,   2,   6,
                              114, 88,   45,  76, 123,  87,  25,  23,
                              200, 122, 150, 90,   92,  87, 177, 244,
                              201,   6,  12,  60,   8,   2,   5,  67,
                                7,  87, 250, 230,  99,   3, 100,  90};

  /* Other Variable Declarations Go Here */



  /* Statistics and Printing Functions Go Here */
	print_statistics(test,SIZE);  
}

/* Add other Implementation File Code Here */
#ifdef VERBOSE
	void print_array(unsigned char* arr, unsigned int length){
		 PRINTF("{");
		for(int i=0; i<length; i++){
	 	  PRINTF("%d",*(arr+i));
 	 	if(i<length-1){
		  PRINTF(", ");
	 	}else{
	   	  PRINTF("}");		
			}
	 	}
	}
#endif

unsigned char find_median(unsigned char* arr, unsigned int length){
	        if(length%2==0){
			 return (arr[length/2]+arr[(length/2)-1])/2;
	 	}else{
		         return arr[(length-1)/2];
       }
}

unsigned char find_mean(unsigned char* arr, unsigned int length){
	float mean=0.0;
        for(short int i=0; i<length; i++){
              mean=mean+arr[i];
	}
     	mean=mean/length;
	return mean;
}

unsigned char find_maximum(unsigned char* arr, unsigned int length){
	int maximum=arr[0];
        for(short int i=1; i<length; i++){
		 if(maximum<arr[i]){
			 maximum=arr[i];								                
		 }
	}
	return maximum;
}

unsigned char find_minimum(unsigned char* arr, unsigned int length){
	int minimum=arr[0];
        for(short int i=1; i<length; i++){
                if(minimum>arr[i]){
			minimum=arr[i];
		}
	}
	return minimum;
}

void sort_array(unsigned char* arr, unsigned int length){
	int temp=0;
        for(int i=0; i<length-1; i++){
		for(int j=0; j<length-1; j++){
			if(arr[j]<arr[j+1]){
				temp=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=temp;
			}
		}
	}
}

void print_statistics(unsigned char* arr, unsigned int length){
	PRINTF("Statistics for the following array: ");
        print_array(arr,length);
	PRINTF("\n  median: %d",find_median(arr,length));
	PRINTF("\n  mean: %d",find_mean(arr,length));
	PRINTF("\n  minimum: %d",find_minimum(arr,length));
	PRINTF("\n  maximum: %d",find_maximum(arr,length));
	PRINTF("\n  sorted array: ");
	sort_array(arr,length);
	print_array(arr,length);
	PRINTF("\n\n");
}

























