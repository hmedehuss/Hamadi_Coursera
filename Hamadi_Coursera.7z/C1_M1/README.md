Hussein HAMADI - Assignement 1 / Introduction to Embedded system 
